# MySQL and Vaadin integration example using Spring JDBC template

This example shows how to build a web UI for an existing MySQL database using plain Java.

See the complete guide at: [https://vaadin.com/blog/-/blogs/building-a-web-ui-for-mysql-databases-in-plain-java-](https://vaadin.com/blog/-/blogs/building-a-web-ui-for-mysql-databases-in-plain-java-).
