package com.example;

import com.vaadin.data.Binder;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@SpringUI
public class VaadinUI extends UI {

    @Autowired
    private BeverageServ service;
    private Beverage beverage;

    private Binder<Beverage> binder = new Binder<>(Beverage.class);

    private Grid<Beverage> grid = new Grid(Beverage.class);
   
    private TextField type = new TextField("Type");
    private TextField subType = new TextField("Sub Type");
    private TextField origin = new TextField("Origin");
    private Button save = new Button("Update", e -> savebeverage());
    private Button addnew = new Button("Add New", e -> addbeverage());
    private Button delete = new Button("Delete", e -> deletebeverage());
    
    @Override
    protected void init(VaadinRequest request) {
        updateGrid();
        grid.setColumns("type", "subType","origin");
        grid.addSelectionListener(e -> updateForm());
        binder.bindInstanceFields(this);
        VerticalLayout layout = new VerticalLayout(grid, type, subType, origin, save, addnew, delete);
        setContent(layout);
        
    }

    private void updateGrid() {
        List<Beverage> beverages = service.findAll();
        grid.setItems(beverages);
        setFormVisible(false);
    }

    private void updateForm() {
        if (grid.asSingleSelect().isEmpty()) {
            setFormVisible(false);
        } else {
            beverage = grid.asSingleSelect().getValue();
            binder.setBean(beverage);
            setFormVisible(true);
        }
    }

    private void setFormVisible(boolean visible) {
        type.setVisible(visible);
        subType.setVisible(visible);
        origin.setVisible(visible);
       // save.setVisible(visible); // delete.setVisible(visible); // addnew.setVisible(visible);
    }
//update
    private void savebeverage() {
        service.update(beverage);
        updateGrid();
    }
//add beverage
    private void addbeverage() {
        service.add(beverage);
        updateGrid();
    }
//delete
      private void deletebeverage() {
        service.delete(beverage);
        updateGrid();
    }
}
