package com.example;

public class Beverage {
    private Long id;
    private String type, subType, origin;

	public Beverage(Long id, String type, String subType, String origin) {
        this.id = id;
        this.type = type;
        this.subType = subType;
        this.origin = origin;
        
    }

    public Long getid() {
        return id;
    }

    public void setid(Long id) {
        this.id = id;
    }

    public String gettype() {
        return type;
    }

    public void settype(String type) {
        this.type = type;
    }

    public String getsubType() {
        return subType;
    }

    public void setsubType(String subType) {
        this.subType = subType;
    }
    public String getorigin() {
		return origin;
	}

	public void setorigin(String origin) {
		this.origin = origin;
	}
}
