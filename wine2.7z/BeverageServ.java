package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BeverageServ {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Beverage> findAll() {
        return jdbcTemplate.query("SELECT id, type, subType, origin FROM beverage",
                (rs, rowNum) -> new Beverage(rs.getLong("id"), rs.getString("type"), rs.getString("subType"), rs.getString("subType")));
    }

    public void update(Beverage beverage) {
        jdbcTemplate.update("UPDATE beverage SET type=?, subType=?, origin=? WHERE id=?",
                beverage.gettype(), beverage.getsubType(), beverage.getorigin(), beverage.getid());
    }
    public void add(Beverage beverage) {
        jdbcTemplate.update("INSERT INTO beverage SET type=?, subType=?, origin=?",
                beverage.gettype(), beverage.getsubType(), beverage.getorigin());
    }
    public void delete(Beverage beverage) {
        jdbcTemplate.update("DELETE FROM beverage WHERE id=?",
        		beverage.getid());
    }
}
